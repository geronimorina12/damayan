const s="/build/assets/logo1-Bm8aQSN7.png";export{s as _};
