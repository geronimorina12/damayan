const s="/build/assets/not_found-Bxx9Mhji.svg";export{s as _};
